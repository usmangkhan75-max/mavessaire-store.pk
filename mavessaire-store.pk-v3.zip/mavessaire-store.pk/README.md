# MAVESSAIRE — The Art of Impression

Official luxury fragrance storefront (`mavessaire-store.pk`).

## Structure
- `index.html` — Complete single-page e-commerce storefront with AI Scent Sommelier, live search & category filters, slide-over shopping bag, express checkout, and order receipt tracking.
- `images/` — Studio product photography (`tk4-impression.png`, `the-one.png`, `her-love.png`).
- `.github/workflows/deploy.yml` — Automated GitHub Pages deployment on push to `main`.

## Highlights
- **All Fragrances Under Rs. 3,000** (Rs. 2,350 – Rs. 2,950).
- **Distinctive Flacons:** Heavy square glass bottles for Men & Unisex (`TK4 Impression`, `The One`, `Oud Atelier`, `Azure Mist`, `Noir Essence`) and cylindrical round-shoulder glass bottles for Women (`Her Love`, `Velvet Bloom`, `Rose Élan`).
- **Free Delivery** across Pakistan on orders of **Rs. 5,000+**.
